// ***************************** Data Table js ***************************** 
new DataTable('#example', {
    searching: false,   // Removes the search box
    lengthChange: false, 
    // paging: false,      // Disables pagination
    // ordering: false     // Disables column ordering
  });


  $(".meta-tags").select2({
    tags: true
});